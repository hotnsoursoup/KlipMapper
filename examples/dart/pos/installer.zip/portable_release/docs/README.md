# Luxe Nails POS - Portable Distribution

## Installation Instructions

### Step 1: Check System Requirements
- Windows 10 or Windows 11 (64-bit)
- At least 4GB RAM
- At least 500MB free disk space
- Visual C++ Redistributable 2022 (automatically installed if needed)

**No development tools or additional software required**

### Step 2: Install Prerequisites (if needed)
If the application fails to start, you may need to install:

**Visual C++ Redistributable 2022 (x64)**
- Download from Microsoft or use the installer in the `redist/` folder
- This is required for the Flutter engine to work

### Step 3: Launch Application
1. Double-click `Launch Luxe Nails POS.bat`
2. The application will start in fullscreen mode
3. Use F11 or Alt+Enter to toggle fullscreen
4. Press Escape to exit

## Files Included
```
portable_release/
├── Launch Luxe Nails POS.bat    # Launcher script
├── app/                         # Application files
│   ├── luxe_pos.exe            # Main executable
│   ├── flutter_windows.dll     # Flutter engine
│   ├── flutter_secure_storage_windows_plugin.dll  # Security plugin
│   ├── sqlite3.dll             # SQLite database
│   ├── sqlite3_flutter_libs_plugin.dll           # SQLite plugin
│   ├── data/                   # App bundle
│   └── assets/                 # Database and icons
├── redist/                     # Redistributables
└── docs/                       # Documentation
```

## Kiosk Mode Setup
For automatic startup on boot:
1. Copy `Launch Luxe Nails POS.bat` to Windows Startup folder
2. Windows Key + R, type `shell:startup`, press Enter
3. Paste the launcher script there

## Troubleshooting

### Application won't start
- Install Visual C++ Redistributable from redist/ folder
- Ensure all files are in the app/ folder
- Check Windows Event Viewer for detailed errors

### Performance issues
- Close other applications
- Ensure adequate free disk space
- Check that antivirus isn't blocking the app

### Database issues
- Ensure app/ folder has write permissions
- Check that database files aren't corrupted
- Try running as administrator

## Support
For technical support, contact: support@luxenails.com

Version: 1.0.0
Build Date: Mon 08/04/2025
